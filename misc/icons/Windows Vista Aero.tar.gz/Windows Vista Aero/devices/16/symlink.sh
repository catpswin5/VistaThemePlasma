ln -s monitor.png video-display-brightness.png
ln -s monitor.png brightness-high.png
ln -s monitor.png brightness-high-symbolic.png
